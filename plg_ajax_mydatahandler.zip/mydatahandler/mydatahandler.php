<?php
defined('_JEXEC') or die;

use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\CMS\Factory;
use Joomla\CMS\Response\JsonResponse;

class PlgAjaxMydatahandler extends CMSPlugin
{
    protected $autoloadLanguage = false;

    private function getDbo()
    {
        return Factory::getDbo();
    }

    private function getTable()
    {
        return '#__mydata';
    }

    public function onAjaxMydatahandler()
    {
        $app = Factory::getApplication();
        $input = $app->input;

        $task = $input->getCmd('task');

        switch ($task) {
            case 'insert':
                return $this->insertData(
                    $input->getString('name'),
                    $input->getString('value')
                );
            case 'get':
                return $this->getData(
                    $input->getInt('id')
                );
            case 'update':
                return $this->updateData(
                    $input->getInt('id'),
                    $input->getString('value')
                );
            case 'delete':
                return $this->deleteData(
                    $input->getInt('id')
                );
            default:
                return new JsonResponse(['error' => 'Invalid task'], 400);
        }
    }

    private function insertData($name, $value)
    {
        $db = $this->getDbo();
        $query = $db->getQuery(true);

        $columns = ['name', 'value'];
        $values = [
            $db->quote($name),
            $db->quote($value)
        ];

        $query->insert($db->quoteName($this->getTable()))
              ->columns($db->quoteName($columns))
              ->values(implode(',', $values));

        $db->setQuery($query);
        $db->execute();

        return new JsonResponse(['id' => $db->insertid(), 'status' => 'inserted']);
    }

    private function getData($id)
    {
        $db = $this->getDbo();
        $query = $db->getQuery(true)
            ->select('*')
            ->from($db->quoteName($this->getTable()))
            ->where('id = ' . (int)$id);

        $db->setQuery($query);
        $result = $db->loadAssoc();

        return new JsonResponse($result);
    }

    private function updateData($id, $value)
    {
        $db = $this->getDbo();
        $query = $db->getQuery(true)
            ->update($db->quoteName($this->getTable()))
            ->set('value = ' . $db->quote($value))
            ->where('id = ' . (int)$id);

        $db->setQuery($query);
        $db->execute();

        return new JsonResponse(['status' => 'updated']);
    }

    private function deleteData($id)
    {
        $db = $this->getDbo();
        $query = $db->getQuery(true)
            ->delete($db->quoteName($this->getTable()))
            ->where('id = ' . (int)$id);

        $db->setQuery($query);
        $db->execute();

        return new JsonResponse(['status' => 'deleted']);
    }
}
