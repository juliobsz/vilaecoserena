<?php
defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\MVC\Model\BaseDatabaseModel;
use Joomla\CMS\Response\JsonResponse;
use Joomla\CMS\Router\Route;
use Joomla\Component\Content\Site\Helper\RouteHelper;

class PlgAjaxNewsflash extends JPlugin
{
    public function onAjaxNewsflash()
    {
        $app = Factory::getApplication();
        $input = $app->input;

        $offset = $input->getInt('offset', 0);
        $limit = 4;

        BaseDatabaseModel::addIncludePath(JPATH_SITE . '/components/com_content/src/Model', 'ContentModel');
        $model = BaseDatabaseModel::getInstance('Articles', 'ContentModel', ['ignore_request' => true]);
        $model->setState('list.start', $offset);
        $model->setState('list.limit', $limit);
        $model->setState('filter.published', 1);

        // Categoria fixa por exemplo
        $model->setState('filter.category_id', array(5));

        $items = $model->getItems();
        $html = '';
        foreach ($items as $item) {
            $title = htmlspecialchars($item->title, ENT_QUOTES, 'UTF-8');
            $link = Route::_(RouteHelper::getArticleRoute($item->id, $item->catid));
            $html .= '<div class="news-item"><a href="' . $link . '">' . $title . '</a></div>';
        }

        $total = $model->getTotal();
        $hasMore = ($offset + $limit) < $total;

        return new JsonResponse([
            'html' => $html,
            'hasMore' => $hasMore
        ]);
    }
}
