<?php
defined('_JEXEC') or die;

require __DIR__ . '/tmpl/default.php';
