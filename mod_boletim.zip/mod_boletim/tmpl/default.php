<?php
defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Uri\Uri;

// --- CONFIGURAÇÃO ---
$boletimDir = JPATH_SITE . '/images/boletim';
$boletimUrl = Uri::root() . 'images/boletim';

// 1. LER TODOS OS ARQUIVOS PDF DA PASTA
$allFiles = glob($boletimDir . '/*.pdf');
if (!$allFiles) { $allFiles = []; }
rsort($allFiles);

// 2. EXTRAIR ANOS ÚNICOS
$yearsMap = [];
foreach ($allFiles as $filepath) {
    $filename = basename($filepath);
    if (preg_match('/-(\d{2})\.pdf$/i', $filename, $m)) {
        $y = 2000 + (int) $m[1];
        $yearsMap[$y] = true;
    }
}
$availableYears = array_keys($yearsMap);
rsort($availableYears);

// 3. PROCESSAR FILTRO DE ANO
$input = Factory::getApplication()->input;
$selectedYear = $input->getString('ano', 'all');

// Filtra os arquivos
$filteredFiles = [];
foreach ($allFiles as $filepath) {
    $fn = basename($filepath);
    if ($selectedYear === 'all' || strpos($fn, '-' . substr($selectedYear, -2) . '.pdf') !== false) {
        $filteredFiles[] = $filepath;
    }
}

// Funções auxiliares
function parseFilenameBE($filename) {
    $name = pathinfo($filename, PATHINFO_FILENAME);
    $parts = explode('-', $name);
    $yy = end($parts);
    $year = 2000 + (int) $yy;
    $number = strtoupper(str_replace('be', '', implode('-', array_slice($parts, 0, -1))));
    return [$number, $year, $name];
}
function humanBytes($b) {
    $u = ['Bytes','KB','MB','GB','TB']; $i=0;
    while ($b>=1024 && $i<count($u)-1) { $b/=1024; $i++; }
    return number_format($b, $i?2:0, ',', '.') . ' ' . $u[$i];
}
?>
<div style="font-family: Arial, sans-serif; max-width: 1000px; margin: 20px auto; border: 1px solid #ccc; background-color: #fff;">

  <div style="background-color:#f2f2f2;border-bottom:2px solid #ccc;padding:10px;text-align:center;font-size:20px;font-weight:bold;color:#333;">
    Boletim do Exército
  </div>

  <div style="padding:15px;border-bottom:1px solid #ccc;">
    <div style="font-size:16px;font-weight:bold;margin-bottom:10px;">PESQUISA AVANÇADA - BE</div>
    <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;">
      <span>Filtrar por ano:</span>
      <?php
        $uri = Uri::getInstance();
        $base = htmlspecialchars($uri->toString(['scheme','host','port','path']), ENT_QUOTES, 'UTF-8');
        $sep  = '?';
        $linkAll = $base . $sep . 'ano=all';
        $isAll = ($selectedYear === 'all');
        echo '<a href="'. $linkAll .'"'.($isAll?' style="font-weight:bold;text-decoration:underline;"':'').'>Todos</a>';
        foreach ($availableYears as $y) {
            $link = $base . $sep . 'ano=' . $y;
            $sel  = ($selectedYear == (string)$y) ? ' style="font-weight:bold;text-decoration:underline;"' : '';
            echo '<a href="'.$link.'"'.$sel.'>'.$y.'</a> ';
        }
      ?>
    </div>
  </div>

  <table style="width:100%;border-collapse:collapse;font-size:14px;">
    <thead style="background-color:#f2f2f2;font-weight:bold;">
      <tr>
        <th style="padding:8px;border:1px solid #ddd;text-align:left;">NR</th>
        <th style="padding:8px;border:1px solid #ddd;text-align:left;">ARQUIVO</th>
        <th style="padding:8px;border:1px solid #ddd;text-align:left;">TAMANHO</th>
        <th style="padding:8px;border:1px solid #ddd;text-align:left;">DESCRIÇÃO</th>
        <th style="padding:8px;border:1px solid #ddd;text-align:center;">AÇÃO</th>
      </tr>
    </thead>
    <tbody>
      <?php if (empty($filteredFiles)) : ?>
        <tr><td colspan="5" style="padding:20px;text-align:center;border:1px solid #ddd;">Nenhum boletim encontrado.</td></tr>
      <?php else :
        $i = 0;
        foreach ($filteredFiles as $fp) :
          $fn = basename($fp);
          list($nr, $yr, $desc) = parseFilenameBE($fn);
          $url  = $boletimUrl . '/' . rawurlencode($fn);
          $size = (file_exists($fp) ? filesize($fp) : 0);
          $bg   = ($i++ % 2) ? '#f9f9f9' : '#fff';
      ?>
        <tr style="background-color:<?= $bg ?>">
          <td style="padding:8px;border:1px solid #ddd;"><?= htmlspecialchars($nr, ENT_QUOTES, 'UTF-8') ?></td>
          <td style="padding:8px;border:1px solid #ddd;">
            <a href="<?= $url ?>" target="_blank" style="text-decoration:none;color:#000;"><?= htmlspecialchars($fn, ENT_QUOTES, 'UTF-8') ?></a>
          </td>
          <td style="padding:8px;border:1px solid #ddd;"><?= humanBytes($size) ?></td>
          <td style="padding:8px;border:1px solid #ddd;"><?= htmlspecialchars($desc, ENT_QUOTES, 'UTF-8') ?></td>
          <td style="padding:8px;border:1px solid #ddd;text-align:center;">
            <a href="<?= $url ?>" download>Baixar</a>
          </td>
        </tr>
      <?php endforeach; endif; ?>
    </tbody>
  </table>
</div>
