<?php
defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\CMS\Response\JsonResponse;
use Joomla\CMS\Table\Table;
use Joomla\CMS\Filter\OutputFilter;

class PlgAjaxCreateSTIRequest extends CMSPlugin
{
    public function onAjaxCreateSTIRequest()
    {
        // Get input from the request
        $app = Factory::getApplication();
        $input = json_decode(file_get_contents('php://input'), true);

        $title = $input['title'] ?? '';
        $description = $input['description'] ?? '';

        if (empty($title) || empty($description)) {
            echo new JsonResponse(null, 'Missing title or description.', false);
            return;
        }

        // You can enforce login if needed:
        /*
        $user = Factory::getUser();
        if ($user->guest) {
            echo new JsonResponse(null, 'Access denied. Please log in.', false);
            return;
        }
        */

        // Prepare article data
        $data = [
            'title' => $title,
            'alias' => OutputFilter::stringURLSafe($title),
            'catid' => 2, // Replace with your actual category ID
            'state' => 1, // 1 = published
            'introtext' => $description,
            'fulltext' => '',
            'language' => '*',
        ];

        try {
            Table::addIncludePath(JPATH_ADMINISTRATOR . '/components/com_content/tables');
            $article = Table::getInstance('Content', 'JTable');
            $article->bind($data);
            $article->check();
            $article->store();

            echo new JsonResponse(['id' => $article->id], 'Article created successfully.');
        } catch (\Exception $e) {
            echo new JsonResponse(null, $e->getMessage(), false);
        }
    }
}
